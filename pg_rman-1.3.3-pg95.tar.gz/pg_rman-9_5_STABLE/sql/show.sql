\! bash sql/show.sh
