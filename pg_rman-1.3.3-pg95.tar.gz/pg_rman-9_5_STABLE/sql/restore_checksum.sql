\! bash sql/restore.sh "--with-checksum"

