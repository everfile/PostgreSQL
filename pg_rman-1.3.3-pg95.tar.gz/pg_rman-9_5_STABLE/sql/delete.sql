\! bash sql/delete.sh
