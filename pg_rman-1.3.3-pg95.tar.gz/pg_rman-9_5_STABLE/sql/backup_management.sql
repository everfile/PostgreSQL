\! bash sql/backup_management.sh
