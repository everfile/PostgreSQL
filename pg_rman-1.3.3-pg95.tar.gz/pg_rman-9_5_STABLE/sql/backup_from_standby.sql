\! bash sql/backup_from_standby.sh

