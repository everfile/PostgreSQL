\! bash sql/arc_srv_log_management.sh
