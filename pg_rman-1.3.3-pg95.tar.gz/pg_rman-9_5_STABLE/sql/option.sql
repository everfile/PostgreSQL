\! bash sql/option.sh
